<?php
/* Database connection settings */
	$servername = "localhost";
    $username = "id17681186_someone";		//put your phpmyadmin username.(default is "root")
    $password = "D>VJGqb8|s<|+R)X";			//if your phpmyadmin has a password put it here.(default is "root")
    $dbname = "id17681186_test";
    
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }
?>