<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/header.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;300;500;700&display=swap" rel="stylesheet">
</head>

<header>
	<div class="topnav">
		<h1>Biometric attendance</h1>
		<div class="links">
			<a href="index.php">Users</a>
			<a href="UsersLog.php">Users Log</a>
			<a href="ManageUsers.php">Manage Users</a>
		</div>
	</div>
</header>
